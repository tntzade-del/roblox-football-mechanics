--!strict
-- Demo controls: hold and release left mouse button to shoot; hold E to dribble.
local UserInputService = game:GetService("UserInputService")
local RunService = game:GetService("RunService")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local Config = require(ReplicatedStorage:WaitForChild("FootballConfig"))
local remotes = ReplicatedStorage:WaitForChild("FootballRemotes")
local shoot = remotes:WaitForChild("Shoot") :: RemoteEvent
local dribble = remotes:WaitForChild("Dribble") :: RemoteEvent
local camera = workspace.CurrentCamera
local chargingFrom: number? = nil
local dribbling = false
local elapsed = 0

UserInputService.InputBegan:Connect(function(input: InputObject, processed: boolean)
    if processed then return end
    if input.UserInputType == Enum.UserInputType.MouseButton1 then
        chargingFrom = os.clock()
    elseif input.KeyCode == Enum.KeyCode.E then
        dribbling = true
    end
end)

UserInputService.InputEnded:Connect(function(input: InputObject)
    if input.KeyCode == Enum.KeyCode.E then
        dribbling = false
    elseif input.UserInputType == Enum.UserInputType.MouseButton1 and chargingFrom then
        local duration = math.min(os.clock() - chargingFrom, Config.MaxChargeSeconds)
        chargingFrom = nil
        local mouse = Players.LocalPlayer:GetMouse()
        local target = mouse.Hit.Position
        shoot:FireServer(duration, target)
    end
end)

RunService.RenderStepped:Connect(function(dt: number)
    if not dribbling then elapsed = 0 return end
    elapsed += dt
    if elapsed >= 0.1 then
        elapsed = 0
        dribble:FireServer()
    end
end)
