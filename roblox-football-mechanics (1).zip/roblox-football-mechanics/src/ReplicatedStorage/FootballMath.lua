--!strict
local FootballMath = {}

function FootballMath.chargeAlpha(duration: number, maximum: number): number
    return math.clamp(duration / maximum, 0, 1)
end

function FootballMath.shotSpeed(alpha: number, minimum: number, maximum: number): number
    -- Ease-out gives a satisfying short-charge shot without making full charge mandatory.
    local curved = 1 - (1 - math.clamp(alpha, 0, 1)) ^ 2
    return minimum + (maximum - minimum) * curved
end

function FootballMath.flatDirection(from: Vector3, to: Vector3): Vector3?
    local difference = Vector3.new(to.X - from.X, 0, to.Z - from.Z)
    if difference.Magnitude < 0.01 then
        return nil
    end
    return difference.Unit
end

return FootballMath
