--!strict
-- Original educational example. Roblox server/client scripts share these settings.
return {
    BallName = "Football",
    MaxInteractionDistance = 10,
    KickCooldown = 0.35,
    MinShotSpeed = 38,
    MaxShotSpeed = 105,
    MaxChargeSeconds = 1.4,
    ShotLift = 0.18,
    DribbleSpeed = 19,
    DribbleMaxDistance = 7,
    DribbleTargetOffset = 3.5,
    DribbleAcceleration = 13,
    DribbleRequestCooldown = 0.08,
}
