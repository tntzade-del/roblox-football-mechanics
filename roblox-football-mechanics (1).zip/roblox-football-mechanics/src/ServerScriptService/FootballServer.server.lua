--!strict
-- Server-authoritative demonstration of charge shooting and tap-to-dribble.
-- Put an unanchored spherical BasePart named "Football" in Workspace.
local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local RunService = game:GetService("RunService")
local Config = require(ReplicatedStorage:WaitForChild("FootballConfig"))
local FootballMath = require(ReplicatedStorage:WaitForChild("FootballMath"))

local ball = workspace:WaitForChild(Config.BallName) :: BasePart
assert(ball:IsA("BasePart"), "Workspace.Football must be a BasePart")
assert(not ball.Anchored, "Workspace.Football must be unanchored")
ball:SetNetworkOwner(nil) -- authoritative physics in this demonstration

local remotes = Instance.new("Folder")
remotes.Name = "FootballRemotes"
remotes.Parent = ReplicatedStorage
local shoot = Instance.new("RemoteEvent")
shoot.Name = "Shoot"
shoot.Parent = remotes
local dribble = Instance.new("RemoteEvent")
dribble.Name = "Dribble"
dribble.Parent = remotes

local lastShot: {[Player]: number} = {}
local lastDribble: {[Player]: number} = {}
local activeDribbler: Player? = nil
local dribbleExpires = 0

local function playerRoot(player: Player): BasePart?
    local character = player.Character
    local root = if character then character:FindFirstChild("HumanoidRootPart") else nil
    local humanoid = if character then character:FindFirstChildOfClass("Humanoid") else nil
    if root and root:IsA("BasePart") and humanoid and humanoid.Health > 0 then
        return root
    end
    return nil
end

local function closeEnough(root: BasePart, limit: number): boolean
    return (root.Position - ball.Position).Magnitude <= limit
end

shoot.OnServerEvent:Connect(function(player: Player, heldSeconds: any, target: any)
    if typeof(heldSeconds) ~= "number" or heldSeconds ~= heldSeconds then return end
    if typeof(target) ~= "Vector3" then return end
    if target.X ~= target.X or target.Y ~= target.Y or target.Z ~= target.Z then return end
    if math.abs(target.X) > 1e6 or math.abs(target.Y) > 1e6 or math.abs(target.Z) > 1e6 then return end
    local root = playerRoot(player)
    if not root or not closeEnough(root, Config.MaxInteractionDistance) then return end
    local now = os.clock()
    if now - (lastShot[player] or -math.huge) < Config.KickCooldown then return end
    local direction = FootballMath.flatDirection(ball.Position, target)
    if not direction then return end
    lastShot[player] = now
    activeDribbler = nil
    local alpha = FootballMath.chargeAlpha(math.clamp(heldSeconds, 0, Config.MaxChargeSeconds), Config.MaxChargeSeconds)
    local speed = FootballMath.shotSpeed(alpha, Config.MinShotSpeed, Config.MaxShotSpeed)
    ball.AssemblyLinearVelocity = (direction + Vector3.new(0, Config.ShotLift, 0)).Unit * speed
    ball.AssemblyAngularVelocity = Vector3.zero
end)

dribble.OnServerEvent:Connect(function(player: Player)
    local root = playerRoot(player)
    if not root or not closeEnough(root, Config.DribbleMaxDistance) then return end
    local now = os.clock()
    if now - (lastDribble[player] or -math.huge) < Config.DribbleRequestCooldown then return end
    lastDribble[player] = now
    activeDribbler = player
    dribbleExpires = now + 0.18
end)

RunService.Heartbeat:Connect(function(dt: number)
    local player = activeDribbler
    if not player or os.clock() > dribbleExpires then
        activeDribbler = nil
        return
    end
    local root = playerRoot(player)
    if not root or not closeEnough(root, Config.DribbleMaxDistance) then
        activeDribbler = nil
        return
    end
    local facing = Vector3.new(root.CFrame.LookVector.X, 0, root.CFrame.LookVector.Z)
    if facing.Magnitude < 0.01 then return end
    local desired = root.Position + facing.Unit * Config.DribbleTargetOffset
    local delta = Vector3.new(desired.X - ball.Position.X, 0, desired.Z - ball.Position.Z)
    local desiredVelocity = if delta.Magnitude > 0.1 then delta.Unit * math.min(Config.DribbleSpeed, delta.Magnitude * 9) else Vector3.zero
    local current = ball.AssemblyLinearVelocity
    local rate = math.clamp(Config.DribbleAcceleration * dt, 0, 1)
    local newPlanar = Vector3.new(current.X, 0, current.Z):Lerp(desiredVelocity, rate)
    ball.AssemblyLinearVelocity = Vector3.new(newPlanar.X, current.Y, newPlanar.Z)
end)

Players.PlayerRemoving:Connect(function(player: Player)
    lastShot[player] = nil
    lastDribble[player] = nil
    if activeDribbler == player then activeDribbler = nil end
end)
