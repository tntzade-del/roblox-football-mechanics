# Roblox Football Mechanics — Open-source Demo

A small, **independent** Roblox Luau learning project demonstrating two football mechanics:

1. **Charge-to-shoot:** hold left mouse button to build shot power, then release toward the mouse cursor.
2. **Close dribbling:** hold **E** while near the ball to nudge it ahead of your character.

The server validates distance, shot requests, cooldowns and controls the ball's physics. The code is meant as an educational starting point, **not a finished multiplayer football framework**.

## Installation in Roblox Studio

1. Start a new baseplate experience.
2. Add a `Part` to `Workspace`, name it **Football**, set `Shape = Ball`, `Anchored = false`, `CanCollide = true`, and set its size to approximately `Vector3.new(3, 3, 3)`. Place it above the baseplate.
3. Copy `src/ReplicatedStorage/FootballConfig.lua` and `FootballMath.lua` into ModuleScripts under **ReplicatedStorage**, retaining the exact names.
4. Copy `src/ServerScriptService/FootballServer.server.lua` into a **Script** named `FootballServer` in ServerScriptService.
5. Copy `src/StarterPlayer/StarterPlayerScripts/FootballClient.client.lua` into a **LocalScript** named `FootballClient` under StarterPlayer > StarterPlayerScripts.
6. Press **Play**. Walk up to the football, hold/release the left mouse button to shoot, or hold **E** to dribble.

You can change shot speed, charge duration and dribble speed in `FootballConfig`.

## Project layout

```text
src/
  ReplicatedStorage/
    FootballConfig.lua
    FootballMath.lua
  ServerScriptService/
    FootballServer.server.lua
  StarterPlayer/
    StarterPlayerScripts/
      FootballClient.client.lua
```

## Limitations and next steps

- This example supports keyboard and mouse; mobile/gamepad UI is not yet included.
- It illustrates server validation but does **not** include full anti-cheat protections, lag compensation, possession arbitration, match rules, or elaborate animations.
- The client currently reports held duration. For competitive play, track charge state on the server using separate start/end messages to prevent forged maximum-charge requests.
- For competitive multiplayer, you will need additional rules to resolve two nearby dribblers competing for the ball.
- Requires playtesting and physics tuning in Roblox Studio; this repository has not been verified against a live Roblox session.

## License

MIT — see [LICENSE](LICENSE).

## Open-source disclosure

Created as a standalone educational code example with AI assistance. It is **not** a copy of any proprietary game's source code, and it is **not evidence of downloads, outside contributors, or open-source adoption**.
